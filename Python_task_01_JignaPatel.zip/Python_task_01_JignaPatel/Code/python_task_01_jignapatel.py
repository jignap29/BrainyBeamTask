#Create a custom numpy ufunc (universal function) and apply it to a numpy array.

import numpy as np
def custom_square(x):
    return x ** 2

square_ufunc = np.frompyfunc(custom_square, 1, 1)


arr = np.array([1, 2, 3, 4, 5])

# Apply the ufunc to the NumPy array
result = square_ufunc(arr)

print("Original array:", arr)
print("Squared array:", result)
