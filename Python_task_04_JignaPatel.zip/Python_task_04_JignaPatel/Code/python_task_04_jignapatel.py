#Implement matrix exponentiation for a square matrix using numpy.

import numpy as np
def matrix_exponentiation(matrix, power):

    if not isinstance(matrix, np.ndarray):
        raise ValueError("Input matrix must be a NumPy array.")
    if matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Matrix must be square (n x n).")
    if not isinstance(power, int) or power < 0:
        raise ValueError("Power must be a non-negative integer.")

    return np.linalg.matrix_power(matrix, power)


# Example usage
A = np.array([[2, 3],
              [1, 4]])
power = 3

result = matrix_exponentiation(A, power)
print("Matrix A:")
print(A)
print(f"A^{power}:")
print(result)
