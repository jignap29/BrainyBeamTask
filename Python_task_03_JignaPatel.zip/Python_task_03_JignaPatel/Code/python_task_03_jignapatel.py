#Combine Matplotlib with pandas to create advanced data visualizations with labeled data points and statistical overlays.

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

data = {
    'Category': ['A', 'B', 'C', 'D', 'E'],
    'Value': [23, 45, 12, 67, 34],
    'Variance': [5, 8, 3, 6, 7]
}
df = pd.DataFrame(data)

fig, ax = plt.subplots(figsize=(10, 6))

ax.errorbar(df['Category'], df['Value'], yerr=df['Variance'], fmt='o', label='Data Points', capsize=5)

for i, (category, value) in enumerate(zip(df['Category'], df['Value'])):
    ax.text(i, value + 2, f'{value}', ha='center', color='black', fontsize=10)

categories = np.arange(len(df['Category']))
z = np.polyfit(categories, df['Value'], 1)  # Linear fit
p = np.poly1d(z)
ax.plot(df['Category'], p(categories), '--', color='blue', label='Trend Line')

ax.text(0.5, p(categories).mean() + 5, f'Equation: y = {z[0]:.2f}x + {z[1]:.2f}', color='blue')

sns.set_theme(style="whitegrid")
sns.despine()

ax.set_title("Advanced Visualization ", fontsize=14)
ax.set_xlabel("Category", fontsize=12)
ax.set_ylabel("Value", fontsize=12)
ax.legend()

plt.tight_layout()
plt.show()
