#Create a pandas DataFrame from a JSON object with nested structures.

import pandas as pd

# Nested JSON object
data = {
    "employees": [
        {
            "name": "ABC",
            "age": 30,
            "department": {
                "name": "HR",
                "location": "Ahmedabad"
            }
        },
        {
            "name": "DEF",
            "age": 25,
            "department": {
                "name": "Engineering",
                "location": "Surat"
            }
        },
        {
            "name": "GHI",
            "age": 35,
            "department": {
                "name": "Finance",
                "location": "Baroda"
            }
        }
    ]
}
# Convert nested JSON to a pandas DataFrame
df = pd.json_normalize(data["employees"])
print(df)
