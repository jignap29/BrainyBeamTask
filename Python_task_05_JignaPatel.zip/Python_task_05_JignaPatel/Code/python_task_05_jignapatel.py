#Generate a parallel coordinates plot for visualizing high-dimensional data.

import pandas as pd
import matplotlib.pyplot as plt
from pandas.plotting import parallel_coordinates

data = {
    'Feature1': [1, 2, 3, 4, 5],
    'Feature2': [5, 4, 3, 2, 1],
    'Feature3': [2, 3, 4, 3, 2],
    'Feature4': [9, 7, 8, 6, 10],
    'Class': ['A', 'B', 'A', 'B', 'A']  # Class label for coloring
}
df = pd.DataFrame(data)


plt.figure(figsize=(10, 6))
parallel_coordinates(df, class_column='Class', colormap='viridis')
plt.title("Parallel Coordinates Plot")
plt.xlabel("Features")
plt.ylabel("Values")
plt.grid(True)
plt.show()
